
security delete-keychain $KEYCHAIN_NAME
