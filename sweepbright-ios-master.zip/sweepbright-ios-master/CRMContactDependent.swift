//
//  CRMContactDependent.swift
//  SweepBright
//
//  Created by Kaio Henrique on 5/19/16.
//  Copyright © 2016 madewithlove. All rights reserved.
//

import Foundation

protocol CRMContactDependent {
    var contact: CRMContact! {get set}
}
