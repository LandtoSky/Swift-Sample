//
//  CRMContactFormTableViewCell.swift
//  SweepBright
//
//  Created by Kaio Henrique on 5/26/16.
//  Copyright © 2016 madewithlove. All rights reserved.
//

import UIKit

class CRMContactFormTableViewCell: UITableViewCell {
    @IBOutlet var contactForm: CRMContactForm!
}
