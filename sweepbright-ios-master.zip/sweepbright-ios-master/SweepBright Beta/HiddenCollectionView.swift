//
//  HiddenCollectionView.swift
//  SweepBright Beta
//
//  Created by Kaio Henrique on 11/26/15.
//  Copyright © 2015 madewithlove. All rights reserved.
//

import UIKit

class HiddenCollectionView: UICollectionView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
