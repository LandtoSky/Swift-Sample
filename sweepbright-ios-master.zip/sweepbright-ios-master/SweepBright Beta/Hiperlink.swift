//
//  Hiperlink.swift
//  SweepBright Beta
//
//  Created by Kaio Henrique on 12/3/15.
//  Copyright © 2015 madewithlove. All rights reserved.
//

import Foundation

struct Hiperlink {
    var name: String
    var icon: String
    var segue: String!
}
