//
//  SWBMatchFilterTableViewController.swift
//  SweepBright
//
//  Created by Kaio Henrique on 4/7/16.
//  Copyright © 2016 madewithlove. All rights reserved.
//

import UIKit

class SWBMatchFilterTableViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
