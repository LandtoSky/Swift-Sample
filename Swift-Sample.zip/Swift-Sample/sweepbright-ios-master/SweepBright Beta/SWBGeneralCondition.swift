//
//  SWBGeneralCondition.swift
//  SweepBright
//
//  Created by Kaio Henrique on 2/16/16.
//  Copyright © 2016 madewithlove. All rights reserved.
//

import Foundation

enum SWBGeneralCondition: String {
    case Poor = "poor", Fair = "fair", Good = "good", Mint = "mint", New = "new"
}
