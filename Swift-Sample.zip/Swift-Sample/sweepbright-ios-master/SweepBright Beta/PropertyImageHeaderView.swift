//
//  PropertyImageHeaderView.swift
//  SweepBright Beta
//
//  Created by Kaio Henrique on 11/25/15.
//  Copyright © 2015 madewithlove. All rights reserved.
//

import UIKit

class PropertyImageHeaderView: UICollectionReusableView {

    @IBOutlet weak var title: UILabel!
}
