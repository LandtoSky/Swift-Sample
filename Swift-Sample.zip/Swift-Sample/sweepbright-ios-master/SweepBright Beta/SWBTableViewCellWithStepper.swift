//
//  SWBTableViewCellWithStepper.swift
//  SweepBright
//
//  Created by Kaio Henrique on 3/23/16.
//  Copyright © 2016 madewithlove. All rights reserved.
//

import UIKit

class SWBTableViewCellWithStepper: UITableViewCell {
    @IBOutlet weak var stepper: SWBYearStepper!
}
